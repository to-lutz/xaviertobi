<?php
return [
    'email' => 'thomanekxavier@gmail.com',
    'app_password' => 'cypb baqf zaie yvek', // ohne Leerzeichen
];
?>